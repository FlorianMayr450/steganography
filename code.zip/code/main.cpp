#include "main.h"
#include <iostream>

using namespace std;

void Main() {

	cout << "-----------------------------------\n" << "Would you like to read or write?\n" << "read: 0                 write: 1\n" << "-----------------------------------\n";
	char answer;
	cin >> answer;
	if (answer == 'C') {
		cout << "-----------------------------------\n" << "Quiting...\n" << "-----------------------------------\n";
	}
	else if (answer == '0') {
		cout << "-----------------------------------\n" << "Entering read mode\n" << "-----------------------------------\n";
		read();
	}
	else {
		cout << "-----------------------------------\n" << "Entering write mode\n" << "-----------------------------------\n";
		write();
	}
}

int main() {
	Main();
	return 0;
}
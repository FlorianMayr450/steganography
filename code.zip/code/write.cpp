#include "main.h"
#include <iostream>
#include <string>
#include "Image.h"
#include <vector>
#include <bitset>

#define IS_INTEGRAL(T) typename std::enable_if< std::is_integral<T>::value >::type* = 0

template<class T>
std::string integral_to_binary_string(T byte, IS_INTEGRAL(T))
{
	std::bitset<sizeof(T)* CHAR_BIT> bs(byte);
	return bs.to_string();
}

std::vector<bool> toBitCode(std::string message) {
	std::vector<bool> bitCode;
	for (int i = 0; i < message.size(); i++) {
		char x = message[i];
		std::string bit = integral_to_binary_string(x);
		for (int i = 0; i < bit.size(); i++) {
			if (bit[i] == '0') {
				bitCode.push_back(false);
			}
			else {
				bitCode.push_back(true);
			}
		}
	}

	return bitCode;
}

void write() {

	std::cout << "Please input base path\n" << "-----------------------------------\n";
	std::string base_p;
	std::cin >> base_p;


	std::cout << "-----------------------------------\n" << "Please input output path\n" << "-----------------------------------\n";
	std::string output_p;
	std::cin >> output_p;

	std::cout << "-----------------------------------\n" << "Please input message\n" << "-----------------------------------\n";
	std::string message;
	std::cin >> message;

	//TODO: Fix bug regarding pixel manipulation

	Image image(0, 0);
	image.Read(base_p.c_str());
	std::vector<bool> bitCode = toBitCode(message);

	std::vector<bool> bitCode2;
	int size = bitCode.size()/8;
	std::string bit = integral_to_binary_string(size);
	for (int i = 0; i < bit.size(); i++) {
		if (bit[i] == '0') {
			bitCode2.push_back(false);
		}
		else {
			bitCode2.push_back(true);
		}
	}
	for (int i = 0; i < bitCode.size(); i++) {
		bitCode2.push_back(bitCode[i]);
	}

	for (int i = 0; i < bitCode2.size(); i++) {
		Color c = image.GetColor(i%image.m_width, i/image.m_width);
		int cr = c.r;
		if (bitCode2[i]) {
			cr = (cr % 2 == 0 ? cr + 1 : cr);
		}
		else {
			cr = (cr % 2 == 0 ? cr : cr + 1);
		}
		c.r = cr;
		image.SetColor(c, i % image.m_width, i / image.m_width);
	}

	image.Export(output_p.c_str());

	Main();
}
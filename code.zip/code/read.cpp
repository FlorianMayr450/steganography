#include "main.h"
#include "image.h"
#include <iostream>
#include <string>
#include <vector>
#include <cmath>

int bitCodeToInt(std::vector<bool> code) {
	int x = 0;
	for (int i = code.size()-1; i >= 0; i--) {
		int a = code.size()-1 - i;
		if (code[i]) {
			x += std::pow(2, a);
		}
	}
	return x;
}

void read() {
	std::cout << "Please input path\n" << "-----------------------------------\n";
	std::string input_p;
	std::cin >> input_p;

	Image image(0, 0);
	image.Read(input_p.c_str());

	std::vector<bool> size_bitCode;
	for (int i = 0; i < 32; i++) {
		Color c = image.GetColor(i % image.m_width, i / image.m_width);
		int r = c.r;
		size_bitCode.push_back(!(r % 2 == 0));
	}
	int size = bitCodeToInt(size_bitCode);

	std::string message = "";
	for (int i = 4; i < size + 4; i++) {
		std::vector<bool> bitCode;
		for (int j = i*8; j < i*8 + 8; j++) {
			Color c = image.GetColor(j % image.m_width, j / image.m_width);
			int r = c.r;
			bitCode.push_back(!(r % 2 == 0));
		}
		char c = (char)bitCodeToInt(bitCode);
		message += c;
	}

	std::cout<< "-----------------------------------\n" << message << "\n";

	Main();

}
#pragma once
void read();
void write();
void Main();